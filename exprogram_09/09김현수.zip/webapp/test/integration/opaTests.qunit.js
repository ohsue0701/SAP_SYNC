/* global QUnit */

sap.ui.require(["exam/exprogram09/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
