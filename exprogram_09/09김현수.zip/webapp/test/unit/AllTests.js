sap.ui.define([
	"exam/exprogram_09/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
